import http.server
import socketserver
from urllib.parse import urlparse, parse_qs

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, stream_url, password, *args, **kwargs):
        self.stream_url = stream_url
        self.password = password
        super().__init__(*args, directory="/", **kwargs)

    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        input_pass = query.get('pass', [None])[0]

        if input_pass != self.password:
            self.send_response(403)
            self.end_headers()
            self.wfile.write(b"Acceso denegado. Contraseña incorrecta.")
            return

        if self.path.startswith("/?pass="):
            self.send_response(200)
            self.send_header("Content-type", "video/mp4")
            self.end_headers()
            with open(self.stream_url, "rb") as f:
                self.wfile.write(f.read())
        else:
            self.send_error(404, "Not Found")

def start_server(stream_url, port, password):
    handler = lambda *args, **kwargs: CustomHandler(stream_url, password, *args, **kwargs)
    with socketserver.TCPServer(("", port), handler) as httpd:
        print(f"[SombraTV] Sirviendo en puerto {port} con contraseña {password}")
        httpd.serve_forever()
