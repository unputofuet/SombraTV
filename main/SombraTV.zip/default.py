import xbmc
import xbmcaddon
import xbmcgui
import threading
import random
from resources.lib import server

ADDON = xbmcaddon.Addon()
PORT = 1515

def generate_password():
    return ''.join(random.choices('0123456789', k=6))

def get_current_playing_url():
    player = xbmc.Player()
    if player.isPlaying():
        item = player.getPlayingFile()
        return item
    return None

class StreamButtonMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.running = True

    def onNotification(self, sender, method, data):
        if method == "Player.OnPlay":
            self.show_button()

    def show_button(self):
        xbmcgui.Dialog().notification("SombraTV", "Activando servidor...", xbmcgui.NOTIFICATION_INFO, 3000)
        url = get_current_playing_url()
        if url:
            password = generate_password()
            threading.Thread(target=server.start_server, args=(url, PORT, password)).start()
            xbmcgui.Dialog().ok("SombraTV - Compartir", f"Comparte esta contraseña:\n\n[COLOR gold]{password}[/COLOR]\n\nAccede desde:\nhttp://IP_PUBLICA:{PORT}/?pass=XXXXX")

if __name__ == '__main__':
    monitor = StreamButtonMonitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
